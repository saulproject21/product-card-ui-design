# Product Card Ui Design
## [Watch it on youtube](https://youtu.be/vfo31QNQRg0)
### Product Card Ui Design
Beautiful product card using html and css, contains an image, title, price, description and a buy button. When doing hover effects the content unfolds upwards, creating a beautiful movement.

Don't forget to join the channel for more videos like this.
[Bedimcode](https://www.youtube.com/c/Bedimcode)
